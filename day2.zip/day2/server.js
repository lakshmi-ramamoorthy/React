let express = require("express");
let app = express();
//Middleware - To serve static files. Staic files are html /js/css files
app.use(express.static(__dirname));
app.get("/" , function(request,response){
    response.sendFile(__dirname +"/step1-modules.html")
})
app.listen(3030);
console.log("server is now live")