import React, {Component} from 'react';

export default class HeroComponent extends Component{
    render(){
        return  (this.props.heros.map((val, idx) =>{
            return <div className="box" key = {idx } >
                     <h1> { val.title } </h1>
                     <img src= {val.poster} alt = {val.title}></img>
                     <h2>{ val.firstname + ' ' + val.lastname}</h2>
                     <p>
                         City : <span>{ val.city }</span> <br/>
                         Release Date : <span>{ val.releasedate}</span> <br/>
                         Ticket Price : <span>{ val.ticketprice}</span> <br/>
                     </p>
                </div>
        }))
    }
}