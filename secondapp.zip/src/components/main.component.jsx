import React, {Component} from 'react';
import HeadingComponent from './heading.component';
import HeroComponent from './hero.component';
import '../styles/appstyles.css'

//const  appName = " Heros App ";
const herolist = [{
    "sl": 1,
    "title": "Batman",
    "gender": "male",
    "firstname": "Bruce",
    "lastname": "Wayne",
    "city": "Gotham",
    "ticketprice": 123.45,
    "releasedate": "1/26/2018",
    "poster": "images/batman.jpg"
},
{
    "sl": 2,
    "title": "Superman",
    "gender": "male",
    "firstname": "Clark",
    "lastname": "Kent",
    "city": "Metropolis",
    "ticketprice": 178.67,
    "releasedate": "1/27/2018",
    "poster": "images/superman.jpg"
},
{
    "sl": 3,
    "title": "Ironman",
    "gender": "male",
    "firstname": "Tony",
    "lastname": "Stark",
    "city": "New York",
    "ticketprice": 122.90,
    "releasedate": "1/27/2018",
    "poster": "images/ironman.jpg"    
}, {
    "sl": 4,
    "title": "Phantom",
    "gender": "male",
    "firstname": "Kit",
    "lastname": "Walker",
    "city": "Bhangala",
    "ticketprice": 98.64,
    "releasedate": "1/27/2018",
    "poster": "images/phantom.jpg"
}, {
    "sl": 5,
    "title": "Spiderman",
    "gender": "male",
    "firstname": "Peter",
    "lastname": "Parker",
    "city": "New York",
    "ticketprice": 451.34,
    "releasedate": "9/26/2018",
    "poster": "images/spiderman.jpg"
},
{
    "sl": 6,
    "title": "Wonder Women",
    "gender": "female",
    "firstname": "Princess",
    "lastname": "Diana",
    "city": "Amazon",
    "ticketprice": 341.34,
    "releasedate": "11/26/2018",
    "poster": "images/wonderwoman.png"
}];

export default class MainComponent extends Component{
   comptitle = "Title";
    avengers = ["IronMan" ,"Thor" , "Spiderman"];
    justicelegue = ["B1" , "b2"]
    render(){
        return <div>
        <HeadingComponent title = { this.comptitle }></HeadingComponent>
        <HeroComponent heros = { herolist}></HeroComponent> 
        </div>
    }
     
}