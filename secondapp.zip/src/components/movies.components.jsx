import React, { Component} from 'react'

export default class MoviesComponent extends Component{
    render(){
        return <h1></h1>
    }
}