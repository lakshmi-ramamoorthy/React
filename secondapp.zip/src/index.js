import React from 'react';
import ReactDOM from 'react-dom';
import MainComponent from './components/main.component';


ReactDOM.render(<MainComponent></MainComponent>, document.getElementById('root'));
