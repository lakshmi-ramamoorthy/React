import React from 'react'
import PropTypes from 'prop-types'

class FirstComponent extends React.Component {
    static defaultProps = {
        message : "Default message"
    }

    render(){
        return <div>
        <h1>Hello from 1st {this.props.message} | {this.props.second} </h1>
        <h1>{ this.props.children }</h1>
        </div>
    }
}

FirstComponent.propTypes ={ 
    second : PropTypes.number.isRequired
}

/*FirstComponent.defaultProps = {
        message : "Default message"
}*/

/*function FirstComponent(props){
    return <h1>Callig via function { props.children} </h1>
}*/

export default FirstComponent;