import React from 'react'

/* This component example for state 
State is a  reserved keyword
Props are immutable we cannot change the value.
State can be changed.
*/
class SecondComponent extends React.Component{

    constructor(){
        super();
        this.state = {
            title : "App Title",
            power : 5
        }

        this.clickHandler = this.clickHandler.bind(this);
        this.changeHandler = this.changeHandler.bind(this);
    }

    clickHandler(){
            // To change the state data use set state
            this.setState({
                title : "changed"
            })

            
    }

    changeHandler(evt){
        // To change the state data use set state
        this.setState({
            power : evt.target.value
        })

        
}
    render(){
        return <div>
            <h1>Second component { this.state.title } | { this.state.power}</h1>
            <button onClick= { 
                //this.clickHandler.bind(this)
                //() =>  this.clickHandler()
            this.clickHandler} > Click me </button>
            <input value = { this.state.power } onChange = {this.changeHandler} type="number"></input>

        </div>

        /*
        Fat arrow function has parent scope.. Parent scope has this variable. By default all life cycle methods
        will have default this.Example render . Clickhandler is a custom method hence it does not have this
        */
    }
}

export default SecondComponent;