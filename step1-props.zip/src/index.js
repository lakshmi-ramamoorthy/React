import React from 'react';
import ReactDOM from 'react-dom';

import FirstComponent from './components/first.component'
import SecondComponent from './components/second.component'

//ReactDOM.render(<FirstComponent second ={ 11}> <ul> <li> First item</li></ul></FirstComponent>, document.getElementById('root'));

ReactDOM.render(<SecondComponent></SecondComponent>, document.getElementById('root'));
