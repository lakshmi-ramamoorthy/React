import React from 'react';


class MainApp extends React.Component{
  constructor(){
    super()
    this.state = {
      username : '',
      userage : 0
    }
    this.submitHandler = this.submitHandler.bind(this);
    this.nameChangeHandler = this.nameChangeHandler.bind(this);
    this.ageChangeHandler = this.ageChangeHandler.bind(this);
  }

  submitHandler(evt){
    evt.preventDefault();
    alert(this.state.userage + ' ' + this.state.username)
  }

  nameChangeHandler(evt){
    this.setState({
      username : evt.target.value
    })
  }

  ageChangeHandler(evt){
    this.setState({
      userage : evt.target.value
    })
  }

  render(){
    return <div>
      <h1>Hello from Main Application</h1>
      <hr/>
      <form onSubmit= { this.submitHandler} action="#">
        <label htmlFor="uname">User Name : </label>
        <input  value={this.state.username} onChange={this.nameChangeHandler} id="uname" type = "text"/>
        <br/>
        <label htmlFor="uage">User Age :   </label>
        <input value={this.state.userage} onChange={this.ageChangeHandler} id="uage" type = "text"/>
        <br/>
        <button>Click Me</button>
      </form>
    </div>
  }
}

export default MainApp;
