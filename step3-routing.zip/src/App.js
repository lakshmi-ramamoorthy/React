import React from 'react';
import {BrowserRouter, Route , Link, Switch} from 'react-router-dom'
import BatmanComponent from  './Batman.component'
import SpidermanComponent from  './Spiderman.component'
import SupermanComponent from './Superman.component';
import IronmanComponent from './Ironman.component';
import NotFoundCompound from './notfound.component';


let defaultQty =100;
//Install react routewr dom npm i react-router-dom --save

class MainApp extends React.Component{
  render(){
    return (
      <div>
        <h1>
          Routing Application
        </h1>
             
        <BrowserRouter>
        <ul>
          <li> <Link to="/batman">Batman</Link></li>
          <li> <Link to="/spiderman">Spiderman</Link></li>
          <li> <Link to="/superman">SuperMan</Link></li>
          <li> <Link to= {"/ironman/" + defaultQty}>Ironman</Link></li>
        </ul>
        <Switch>
          <Route path="/"  exact component= {BatmanComponent} />
          <Route path="/spiderman" component= {SpidermanComponent} />
          <Route path="/superman" component= {SupermanComponent } />
          <Route path="/ironman/:qty" component= {IronmanComponent}/>
          <Route component= {NotFoundCompound}/>
        </Switch>
         </BrowserRouter>
        
      </div>
    );
  }
}

export default MainApp;
