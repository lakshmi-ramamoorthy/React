import React from 'react';


class BatmanComponent extends React.Component{
  render(){
    return (
      <div>
        <h1>Batman</h1>
      </div>
    );
  }
}

export default BatmanComponent;