import React from 'react';


class SpidermanComponent extends React.Component{
  render(){
    return (
      <div>
        <h1>SpidermanComponent</h1>
      </div>
    );
  }
}

export default SpidermanComponent;