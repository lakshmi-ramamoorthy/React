import React from 'react';


class SupermanComponent extends React.Component{
  render(){
    return (
      <div>
        <h1>SupermanComponent</h1>
      </div>
    );
  }
}

export default SupermanComponent;