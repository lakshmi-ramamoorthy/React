import React from 'react';
import ReactDOM from 'react-dom';

import MainApp from './App.js'


ReactDOM.render(<MainApp />, document.getElementById('root'));


