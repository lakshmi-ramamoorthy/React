import React , {Component } from 'react';


class NotFoundCompound extends Component{
  render(){
    return (
      <div>
        <h1>NotFoundCompound</h1>
      </div>
    );
  }
}

export default NotFoundCompound;