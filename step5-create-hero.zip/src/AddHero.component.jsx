import React , {Component } from 'react'

export default class AddHeroComponent extends Component {
    render(){
        return (<div>
            <h1>Add</h1>
        </div>)
    }
}