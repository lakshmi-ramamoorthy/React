import React , {Component } from 'react'

export default class HeadingComponent extends Component {
    render(){
        return (<div>
            <h1>Add</h1>
        </div>)
    }
}