import React , {Component } from 'react'
import HeadingComponent from './Heading.component';
import HeroComponent from './Hero.component';



export default class HeroListComponent extends Component {

    constructor(){
        super();
        this.state = {
            heroes : [
               {title : "Ironman" , city : "NY" , power : 3 , fullname : "Tony Stark" },
               {title : "Batman" , city : "Canada" , power : 7 , fullname : "Bruce" },
               {title : "Superman" , city : "California" , power : 8 , fullname : "Clark" },
               {title : "Spiderman" , city : "China" , power : 8 , fullname : "Peter" }
            ]
        }

        this.heroDelete = this.heroDelete.bind(this);
    }

    heroDelete(val){
       // alert ("Delet hero " + val)
       let updatedheros = this.state.heroes.filter ( hero  => hero.title !== val)

       this.setState({
           heroes : updatedheros
       })

       
    }
    
    render(){
        return (<div>
            <h1>Add</h1>
            <HeadingComponent>

            </HeadingComponent>
            <hr/>

                {
                    this.state.heroes.map((hero, idx) =>{
                        return <HeroComponent key ={idx} herodata = {hero} deleteClickHandler = { this.heroDelete.bind(hero,hero.title)}/>
                    })
                }
         
            
        </div>)
    }
}