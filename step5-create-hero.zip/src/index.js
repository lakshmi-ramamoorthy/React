import React from 'react';
import ReactDOM from 'react-dom';
import HeroListComponent from './Herolist.component';

ReactDOM.render(<HeroListComponent/>, document.getElementById('root'));


