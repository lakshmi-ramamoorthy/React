import React , {Component } from 'react'
import { FamilyConsumer } from './familyContext'

const styles = {
    border : '2px solid blue', 
    height : 200,
    width : '60%',
    margin : 'auto',
    marginTop : 40,
}

export default class Child extends Component {
    render(){
        return (
        
        <div style={styles}>
            <h1 style = { {textAlign : 'center'}}> Child </h1>
            <FamilyConsumer>
                {
                    (value) => {
                        return   <h2>{ value }</h2>
                    }
                }
              
            </FamilyConsumer>
        </div>
        
        )
    }
}