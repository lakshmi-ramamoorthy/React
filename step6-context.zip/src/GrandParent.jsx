import React , {Component } from 'react';
import Parent from './Parent';
import { FamilyProvider } from './familyContext';

const styles = {
    border : '2px solid red', 
    height :600 ,
    margin : '20 auto'
}

export default class GrandParent extends Component {
    render(){
        return (
        <FamilyProvider value= "Hello from grand parent">
            <div style={ styles}>
                <h1 style = { {textAlign : 'center'}}> Grand Parent </h1>
                <Parent></Parent>
            </div>
        </FamilyProvider>
        )
    }
}