import React , {Component } from 'react'
import Child from './Child';

const styles = {
    border : '2px solid green', 
    height : 400,
    width : '80%',
    margin : 'auto',
    marginTop : 20,
}

export default class Parent extends Component {
    render(){
        return (<div style={styles}>
            <h1 style = { {textAlign : 'center'}}> Parent </h1>
            <Child></Child>
        </div>)
    }
}