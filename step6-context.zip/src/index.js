import React from 'react';
import ReactDOM from 'react-dom';
import GrandParent from './GrandParent.jsx'



ReactDOM.render(<GrandParent></GrandParent>, document.getElementById('root'));


