import React, { Component } from 'react'
import HeaderComponent from './header.component ';
import ListComponent from './herolist.component';

const appname = "Heroes List"
class App extends Component {
    render() {
        return (
            <div>
                <h1>App Component</h1>
                <HeaderComponent htitle = {appname}></HeaderComponent>
                <ListComponent></ListComponent>
            </div>
            );
    }
}

export default App;