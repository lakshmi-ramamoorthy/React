import React , { Component} from 'react'

 class HeaderComponent extends Component{
    render(){
        return <h1 style={{color: 'red', backgroundColor : 'gray'}}>{ this.props.htitle }</h1>
    }
}

export default HeaderComponent;