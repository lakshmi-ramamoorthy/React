import React , { Component} from 'react'

 class ListComponent extends Component{

    agree= false;
    message = <h1>List Component</h1>;
    render(){

        return this.agree ? this.message : null;
    }
}

export default ListComponent;